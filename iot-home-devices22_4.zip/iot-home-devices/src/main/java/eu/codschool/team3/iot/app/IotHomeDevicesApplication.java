package eu.codschool.team3.iot.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@EntityScan("eu.codschool.team3.iot.entities")
@ComponentScan(basePackages = "eu.codschool.team3.iot")
@EnableJpaRepositories("eu.codschool.team3.iot.repository")
@SpringBootApplication
public class IotHomeDevicesApplication {

	public static void main(String[] args) {
		SpringApplication.run(IotHomeDevicesApplication.class, args);
	}
}