package eu.codschool.team3.iot.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import eu.codschool.team3.iot.entities.*;

@Repository("userroleRepository")
public interface UserroleRepository extends JpaRepository<Role, Integer> {
	Role findBytitle(String rolename);
}
