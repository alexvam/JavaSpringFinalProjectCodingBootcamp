package eu.codschool.team3.iot.service;


import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import eu.codschool.team3.iot.entities.Person;
import eu.codschool.team3.iot.entities.Role;
import eu.codschool.team3.iot.repository.UserRepository;
import eu.codschool.team3.iot.repository.UserroleRepository;

@Service
public class UserServiceImpl implements UserService {
	@Autowired
	UserRepository userRepository;

	@Autowired
	UserroleRepository userRoleRepository;

    @Autowired
    private BCryptPasswordEncoder bCryptPasswordEncoder;
	
    
	@Override
	public Person findByusername(String username) {
		return userRepository.findByemail(username);
	}

	@Override
	public List<Person> findByNameContaining(String searchterm) {
		return userRepository.findByNameContaining(searchterm);
	}
	
	@Override
	public List<Person> findBySurname(String surname) {
		return userRepository.findBySurname(surname);
	}

	@Override
	public void save(Person user) {
		//encrypt the user password
		user.setRole_id(1);
		user.setPassword(bCryptPasswordEncoder.encode(user.getPassword()));
		//Set the user's role as a simple user
		user.setRole(userRoleRepository.findBytitle("USER"));
		userRepository.save(user);
	}

	@Override
	public Person findByUserid(int id) {
		return userRepository.findByid(id);
	}

	@Override
	public List<Person> findAll() {
		return userRepository.findAll();
	}

	@Override
	public List<Person> findByRole(Role role) {
		return userRepository.findByrole_id(role);
	}
	
	private List<Person> users;

    // Love Java 8
    public List<Person> findByUserNameOrEmail(String username) {
    	System.out.println("in findByUserNameOrEmail"+username);
        List<Person> result = users.stream()
            .filter(x -> x.getEmail().equalsIgnoreCase(username))
            .collect(Collectors.toList());
        System.out.println("size"+result.size());
        return result;

    }
	

	
}
