package eu.codschool.team3.iot.service;

import java.util.List;

import eu.codschool.team3.iot.entities.Person;
import eu.codschool.team3.iot.entities.Role;


public interface UserService {
    Person findByusername(String username);
    List<Person> findByNameContaining(String searchterm);
    void save(Person user);
    Person findByUserid(int id);
	List<Person> findAll();
	List<Person> findByRole(Role role);
	List<Person> findBySurname(String surname);
	 

	
}