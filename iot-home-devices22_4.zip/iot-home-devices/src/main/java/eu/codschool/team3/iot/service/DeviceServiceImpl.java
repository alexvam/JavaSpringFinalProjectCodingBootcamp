package eu.codschool.team3.iot.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import eu.codschool.team3.iot.entities.Device;
import eu.codschool.team3.iot.repository.DeviceRepository;

@Service
public class DeviceServiceImpl implements DeviceService {
	@Autowired
	DeviceRepository deviceRepository;
	
	@Override
	public Device findByname(String devicename) {
		// TODO Auto-generated method stub
		return deviceRepository.findByname(devicename);
	}
	
	@Override
	public Device findByid(int id) {
		// TODO Auto-generated method stub
		return deviceRepository.findByid(id);
	}

	@Override
	public List<Device> findByroom_id(int Roomid) {
		// TODO Auto-generated method stub
		return deviceRepository.findByroomid(Roomid);
	}

	@Override
	public List<Device> findAll() {
		// TODO Auto-generated method stub
		return deviceRepository.findAll();
	}

	@Override
	public void save(Device d) {
		// TODO Auto-generated method stub
//		d.
		
		//Set the user's role as a simple user
//		d.setRole(deviceRepository
		
		
		deviceRepository.save(d);
	}

	@Override
	public void delete(Integer id) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void delete(Device d) {
		// TODO Auto-generated method stub
		
	}

	
	

}
