package eu.codschool.team3.iot.service;

import java.util.List;

import eu.codschool.team3.iot.entities.Device;

public interface DeviceService {
	
	Device findByid(int id);
	Device findByname(String devicename);
    List<Device> findByroom_id(int Roomid);
    List<Device> findAll();
    void save(Device d);
	void delete(Integer id);
	void delete(Device d);

}
