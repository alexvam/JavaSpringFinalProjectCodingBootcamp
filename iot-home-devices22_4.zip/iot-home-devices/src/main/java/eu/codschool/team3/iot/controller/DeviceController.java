package eu.codschool.team3.iot.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import eu.codschool.team3.iot.entities.AjaxResponseBody;
import eu.codschool.team3.iot.entities.Device;
import eu.codschool.team3.iot.service.DeviceService;



@Controller
public class DeviceController {
	
	 @Autowired
	 private DeviceService DeviceService;
/*
	 @Autowired
	 private Device device;
	  */
	  

	@RequestMapping(value = "/rooms/list", method = RequestMethod.GET)
	public String getDirectorList(Model model) {
		
		return "fragments/RoomList";
	}

	@GetMapping(value = "/rooms/list/{id}")
	public String getLivingRoomList(Model model, @PathVariable int id) {
	
        switch(id) {
        case (1) :
        	List<Device> device1 = DeviceService.findByroom_id(id);
        	model.addAttribute("devices1", device1);
        	return "fragments/LivingRoom";
           
        case (2) :
        	List<Device> device2 = DeviceService.findByroom_id(id);
    		model.addAttribute("devices2", device2);
        	return "fragments/Kitchen";
        	
        case (3):
        	List<Device> device3 = DeviceService.findByroom_id(id);
    		model.addAttribute("devices3", device3);
        	return "fragments/Bathroom";
          
        case (4) :
        	List<Device> device4 = DeviceService.findByroom_id(id);
    		model.addAttribute("devices4", device4);
        	return "fragments/Bedroom";
        	  	
        case (5) :
        	List<Device> device5 = DeviceService.findByroom_id(id);
    		model.addAttribute("devices5", device5);
        	return "fragments/Garden";
           
        default :
           return "";
        }
        
	}
	
	
	 
	 @RequestMapping(value = "/rooms/list/update/{id}")
	 @ResponseBody
	  public String updateStatusr(@PathVariable int id, String status) {
		 
		  try {
		      Device idevice = DeviceService.findByid(id);
		      if(idevice.getStatus().toString() == "on"){
		    	  idevice.setStatus(eu.codschool.team3.iot.entities.Status.off);
		    	  System.out.println("off");
		      }
		      else{
		    	  idevice.setStatus(eu.codschool.team3.iot.entities.Status.on);
		    	  System.out.println("on");
		      }
		      
		    
		      DeviceService.save(idevice);
		      return "fragments/RoomList";
		    }
		    catch (Exception ex) {
		      return "Error updating status of device: " + ex.toString();
		    }
		    
		 }
	 
	 
	 
	
	 @RequestMapping(value = "/rooms/list/currentStatus/{id}", method = RequestMethod.POST)
	 @ResponseBody
	  public Device getStatusr(Model model,@PathVariable int id) {
		 System.out.println("STATUS://");
		  try {
		      Device idevice = DeviceService.findByid(id);
		      model.addAttribute("status", idevice.getStatus());
		      System.out.println("STATUS://"+idevice.getStatus());
		      return idevice;
		    }
		    catch (Exception ex) {
		    	return null;
/*		      return "Error updating status of device: " + ex.toString();
*/		    }
		    
		 }
	 
	 
	  
  }
	

	


