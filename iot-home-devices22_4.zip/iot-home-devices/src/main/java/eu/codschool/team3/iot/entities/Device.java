package eu.codschool.team3.iot.entities;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "devices")
public class Device {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private int id;
	
	@Column(name = "room_id")
	private int roomid;
	@Column(name = "device_info_id")
	private int device_info_id;
	@Column(name = "name")
	private String name;

	@ManyToOne
	@JoinColumn(name = "device_info_id", insertable = false, updatable = false)
	private Device Device;
	
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "room_id", nullable = false, insertable = false, updatable = false)
	private Room Room;
	
	@ManyToMany(cascade = CascadeType.ALL)
	@JoinTable(name = "person_devices", joinColumns = @JoinColumn(name = "device_id", referencedColumnName = "id"), inverseJoinColumns = @JoinColumn(name = "person_id", referencedColumnName = "id"))
	private Set<Person> Persons;

	@Enumerated(EnumType.STRING)
	@Column(name = "status")
	private Status status;
	@Column(name = "information")
	private String information;
	@Column(name = "enabled",columnDefinition = "char")
	private Boolean enabled;

	public Device() {
		// TODO Auto-generated constructor stub
	}

	public Device(String name, Set<Person> Persons) {
		// TODO Auto-generated constructor stub
		this.name = name;
		this.Persons = Persons;
	}

	public int getRoom_id() {
		return roomid;
	}

	public void setRoom_id(int room_id) {
		this.roomid = room_id;
	}

	public Set<Person> getPersons() {
		return Persons;
	}

	public void setPersons(Set<Person> persons) {
		Persons = persons;
	}

	public Boolean getEnabled() {
		return enabled;
	}

	public void setEnabled(Boolean enabled) {
		this.enabled = enabled;
	}

	@ManyToOne
	@JoinColumn(name = "id")
	@Column(name = "id", unique = true, nullable = false)
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getRoomid() {
		return roomid;
	}

	public void setRoomid(int room_id) {
		this.roomid = room_id;
	}

	public int getDevice_info_id() {
		return device_info_id;
	}

	public void setDevice_info_id(int device_info_id) {
		this.device_info_id = device_info_id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Status getStatus() {
		return status;
	}

	public void setStatus(Status status) {
		this.status = status;
	}

	public String getInformation() {
		return information;
	}

	public void setInformation(String information) {
		this.information = information;
	}

	public boolean isEnabled() {
		return enabled;
	}

	public void setEnabled(boolean enabled) {
		this.enabled = enabled;
	}

	public void save(Device idevice) {
		// TODO Auto-generated method stub
		
	}

}
