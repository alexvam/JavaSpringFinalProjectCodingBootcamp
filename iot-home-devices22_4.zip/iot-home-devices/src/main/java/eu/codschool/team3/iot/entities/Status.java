package eu.codschool.team3.iot.entities;

public enum Status {
	 on,
	 off
}
