package eu.codschool.team3.iot.entities;

import java.util.List;

public class AjaxResponseBody {

    String msg;
    Device devicestatus;
    List<Person> result;
    List<Device> resultdevice;
    //getters and setters
    public String getMsg() {
		return msg;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}
	
    public List<Person> getResult() {
		return result;
	}
    
    public void setDeviceStatus(Device result) {
		this.devicestatus = result;
	}
	
    public Device getDeviceStatus() {
		return devicestatus;
	}
    

	public void setResult(List<Person> result) {
		this.result = result;
	}
	
	public List<Device> getResultDevice() {
			return resultdevice;
		}

		public void setResultDevice(List<Device> result) {
			this.resultdevice = result;
		}
}