package eu.codschool.team3.iot.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import eu.codschool.team3.iot.entities.*;


@Repository("userRepository")
public interface UserRepository extends JpaRepository<Person, Integer> {
	Person findByid(int id);
	Person findByemail(String username);
	List<Person> findBySurname(String Surname);
    List<Person> findByrole_id(Role role);
    List<Person> findByNameContaining(String searchterm);
    void deleteByname(String username);
}