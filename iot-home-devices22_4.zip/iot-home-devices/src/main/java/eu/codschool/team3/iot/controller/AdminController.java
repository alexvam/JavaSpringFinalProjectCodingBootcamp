package eu.codschool.team3.iot.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.ui.Model;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import eu.codschool.team3.iot.entities.AjaxResponseBody;
import eu.codschool.team3.iot.entities.Device;
import eu.codschool.team3.iot.entities.SearchCriteria;
import eu.codschool.team3.iot.service.DeviceService;

@RestController
public class AdminController {

	@Autowired
    private DeviceService deviceService;

	
	 @PostMapping("/admin/search/device")
	    public ResponseEntity<?> getSearchResultViaAjaxDevice(Model model,@Valid @RequestBody SearchCriteria search, Errors errors) {
	    	System.out.println("in getSearchDeviceViaAjax");
	        AjaxResponseBody resultdevice = new AjaxResponseBody();
	        System.out.println("after getSearchDeviceViaAjax");
	        //If error, just return a 400 bad request, along with the error message
	        
	        
	        List<Device> device = deviceService.findAll();

	        if (device.isEmpty()) {
	        	resultdevice.setMsg("no device found!");
	        } else {
	        	resultdevice.setMsg("success");
	        }
	        resultdevice.setResultDevice(device);
	        model.addAttribute("searchdevice", device);
	        return ResponseEntity.ok(resultdevice);

	    }
	 
	 
	 /*@GetMapping("/rooms/list/currentStatus/{id}")
	    public ResponseEntity<?> getcurrStatusViaAjaxDevice(Model model,@PathVariable int id) {
	    	System.out.println("in getSearchDeviceViaAjax");
	        AjaxResponseBody resultstatus = new AjaxResponseBody();
	        System.out.println("after getSearchDeviceViaAjax");
	        //If error, just return a 400 bad request, along with the error message
	        
	        
	        Device idevice  = deviceService.findByid(id);

	        resultstatus.setDeviceStatus(idevice);
	       
	        model.addAttribute("statusid", idevice);
	        System.out.println("status:"+idevice.getStatus().toString());
	        return ResponseEntity.ok(resultstatus);

	    }*/
	 
	 
	 
	 
}
