package eu.codschool.team3.iot.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import eu.codschool.team3.iot.entities.Device;

@Repository("deviceRepository")
public interface DeviceRepository extends JpaRepository<Device, Integer>{
	Device findByid(int id);
    Device findByname(String devicename);
    List<Device> findByroomid(int roomid);
    List<Device> findAll();
    
}
