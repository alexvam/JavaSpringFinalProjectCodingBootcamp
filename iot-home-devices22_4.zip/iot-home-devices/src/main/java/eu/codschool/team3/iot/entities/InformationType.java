package eu.codschool.team3.iot.entities;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;


@Entity
@Table(name = "information_types")
public class InformationType {

	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private int id;
	@Column(name = "title")
	private String title;
	
	@ManyToMany(cascade = CascadeType.ALL)
    @JoinTable(name = "device_info", joinColumns = @JoinColumn(name = "device_type_id", referencedColumnName = "id"), inverseJoinColumns = @JoinColumn(name = "information_type_id", referencedColumnName = "id"))
	private Set<DeviceType> DeviceTypes;
	
	public InformationType() {
		// TODO Auto-generated constructor stub
	}
	
	public InformationType( String title) {
		this.title = title;
		
	}
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	
	
	public Set<DeviceType> getDeviceTypes() {
		return DeviceTypes;
	}
	public void setDeviceTypes(Set<DeviceType> deviceTypes) {
		DeviceTypes = deviceTypes;
	}
	
	
	
	
}
