package eu.codschool.team3.iot.entities;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.Table;


@Entity
@Table(name = "device_types")
public class DeviceType {

	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private int id;
	
	@Column(name = "title")
	private String title;
	
	@ManyToMany(mappedBy = "DeviceTypes", cascade = CascadeType.PERSIST)
	private Set<InformationType> InformationTypes;

	
	public DeviceType() {
		// TODO Auto-generated constructor stub
	}
	
	public DeviceType(String title) {

		this.title = title;
	}
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	
	
	public Set<InformationType> getInformationType() {
		return InformationTypes;
	}
	public void setInformationType(Set<InformationType> informationTypes) {
		InformationTypes = informationTypes;
	}
	
	

}
