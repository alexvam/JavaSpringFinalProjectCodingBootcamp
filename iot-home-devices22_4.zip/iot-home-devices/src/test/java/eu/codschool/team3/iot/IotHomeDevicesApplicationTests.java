package eu.codschool.team3.iot;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest
public class IotHomeDevicesApplicationTests {

	@Test
	public void contextLoads() {
	}

}
